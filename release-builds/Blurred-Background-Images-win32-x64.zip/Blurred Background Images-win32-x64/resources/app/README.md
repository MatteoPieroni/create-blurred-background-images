# Create blurred background images

This repository contains the code for a desktop app that allows the creation of base64 version of blurred images, for gradual loading